"""Validator driver adapters."""

from des.adapters.drivers.validators.mocked_validator import MockedTemplateValidator


__all__ = ["MockedTemplateValidator"]
