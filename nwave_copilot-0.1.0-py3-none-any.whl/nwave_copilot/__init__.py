"""nwave-copilot: GitHub Copilot CLI plugin for the nWave framework."""

__version__ = "0.1.0"
