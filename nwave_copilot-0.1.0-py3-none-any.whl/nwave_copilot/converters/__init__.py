"""Converters package for nwave-copilot."""
